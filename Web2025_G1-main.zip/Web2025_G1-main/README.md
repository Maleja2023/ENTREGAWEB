# Web2025_G1

-------------Para inicializar NPM: npm init-------------
Para bajar la directiva de seguridad que impide la ejecución de SCRIPTS:

1. Ingresar al powershell como administrador (Click secundario)
2. ejecutar: Set-ExecutionPolicy Unrestricted
3. indique que [si] desea bajar la directiva, para eso ingrese [S]

ejecute nuevamente npm init

(Recuerde que debe tener instalado NODE.js)
